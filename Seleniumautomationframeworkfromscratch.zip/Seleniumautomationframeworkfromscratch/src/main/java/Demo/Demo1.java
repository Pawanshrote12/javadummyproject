package Demo;



import java.util.logging.LogManager;

import org.testng.log4testng.Logger;



public class Demo1 {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
